
public class Basic {

}
